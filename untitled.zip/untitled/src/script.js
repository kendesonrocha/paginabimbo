// Aguarda carregamento completo do DOM
document.addEventListener("DOMContentLoaded", () => {
  // ===== EFEITO SPOTLIGHT =====
  const spotlight = document.querySelector(".spotlight");
  const card = document.querySelector(".card");
  
  // Efeito de spotlight que segue o mouse
  document.addEventListener("mousemove", (e) => {
    if (spotlight && card) {
      const cardRect = card.getBoundingClientRect();
      
      // Verifica se o mouse está sobre o card
      if (
        e.clientX >= cardRect.left &&
        e.clientX <= cardRect.right &&
        e.clientY >= cardRect.top &&
        e.clientY <= cardRect.bottom
      ) {
        // Posição relativa ao card
        const x = e.clientX - cardRect.left;
        const y = e.clientY - cardRect.top;
        
        spotlight.style.opacity = "1";
        spotlight.style.background = `radial-gradient(circle at ${x}px ${y}px, rgba(255, 255, 255, 0.15) 0%, transparent 70%)`;
      } else {
        // Reduz a opacidade quando o mouse sai do card
        spotlight.style.opacity = "0.5";
      }
    }
  });
  
  // ===== ANIMAÇÕES DE SCROLL =====
  // Seleciona todos elementos que terão animação
  const animatedElements = document.querySelectorAll(".card, h1, h2, .btn-primary, .btn-secondary");
  
  // Adiciona classes de animação ao carregar a página
  animatedElements.forEach((element, index) => {
    // Atrasa cada elemento por um tempo diferente
    setTimeout(() => {
      element.classList.add("animate-fade-in");
      element.style.opacity = "1";
    }, 100 * index);
  });
  
  // Anima elementos quando eles entram na tela durante o scroll
  const animateOnScroll = () => {
    const featureCards = document.querySelectorAll("#features .p-6");
    const triggerBottom = window.innerHeight * 0.8;
    
    featureCards.forEach((card, index) => {
      const cardTop = card.getBoundingClientRect().top;
      
      if (cardTop < triggerBottom) {
        setTimeout(() => {
          card.style.opacity = "1";
          card.style.transform = "translateY(0)";
        }, 150 * index);
      }
    });
  };
  
  // Inicializa os cards de features com opacidade 0
  document.querySelectorAll("#features .p-6").forEach(card => {
    card.style.opacity = "0";
    card.style.transform = "translateY(20px)";
    card.style.transition = "opacity 0.5s ease, transform 0.5s ease";
  });
  
  // Adiciona evento de scroll
  window.addEventListener("scroll", animateOnScroll);
  
  // Dispara uma vez na carga inicial
  animateOnScroll();
  
  // ===== MENU MOBILE =====
  // Cria botão de menu mobile se não existir
  if (!document.querySelector(".mobile-menu-button")) {
    const header = document.querySelector("header");
    const nav = document.querySelector("nav");
    
    if (header && nav) {
      // Cria botão de menu
      const mobileMenuButton = document.createElement("button");
      mobileMenuButton.classList.add("mobile-menu-button");
      mobileMenuButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16" />
        </svg>
      `;
      mobileMenuButton.style.display = "none";
      mobileMenuButton.style.background = "transparent";
      mobileMenuButton.style.border = "none";
      mobileMenuButton.style.color = "white";
      mobileMenuButton.style.cursor = "pointer";
      
      // Adiciona botão após o logo
      const logo = header.querySelector(".logo");
      if (logo) {
        logo.after(mobileMenuButton);
      } else {
        header.prepend(mobileMenuButton);
      }
      
      // Configura o menu mobile
      nav.classList.add("desktop-menu");
      
      // Cria menu mobile
      const mobileMenu = document.createElement("div");
      mobileMenu.classList.add("mobile-menu");
      mobileMenu.innerHTML = nav.innerHTML;
      mobileMenu.style.position = "fixed";
      mobileMenu.style.top = "0";
      mobileMenu.style.left = "0";
      mobileMenu.style.width = "100%";
      mobileMenu.style.height = "100vh";
      mobileMenu.style.backgroundColor = "rgba(0, 0, 0, 0.95)";
      mobileMenu.style.zIndex = "999";
      mobileMenu.style.display = "flex";
      mobileMenu.style.flexDirection = "column";
      mobileMenu.style.justifyContent = "center";
      mobileMenu.style.alignItems = "center";
      mobileMenu.style.opacity = "0";
      mobileMenu.style.visibility = "hidden";
      mobileMenu.style.transition = "opacity 0.3s ease, visibility 0.3s";
      
      // Estiliza os links do menu
      mobileMenu.querySelectorAll("a").forEach(link => {
        link.style.display = "block";
        link.style.fontSize = "1.5rem";
        link.style.marginBottom = "1.5rem";
      });
      
      // Botão de fechar menu
      const closeButton = document.createElement("button");
      closeButton.innerHTML = `
        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12" />
        </svg>
      `;
      closeButton.style.position = "absolute";
      closeButton.style.top = "1.5rem";
      closeButton.style.right = "1.5rem";
      closeButton.style.background = "transparent";
      closeButton.style.border = "none";
      closeButton.style.color = "white";
      closeButton.style.cursor = "pointer";
      
      mobileMenu.prepend(closeButton);
      document.body.appendChild(mobileMenu);
      
      // Toggle do menu
      mobileMenuButton.addEventListener("click", () => {
        mobileMenu.style.visibility = "visible";
        mobileMenu.style.opacity = "1";
      });
      
      closeButton.addEventListener("click", () => {
        mobileMenu.style.opacity = "0";
        setTimeout(() => {
          mobileMenu.style.visibility = "hidden";
        }, 300);
      });
      
      // Fecha menu ao clicar nos links
      mobileMenu.querySelectorAll("a").forEach(link => {
        link.addEventListener("click", () => {
          mobileMenu.style.opacity = "0";
          setTimeout(() => {
            mobileMenu.style.visibility = "hidden";
          }, 300);
        });
      });
      
      // Atualiza a visibilidade do botão de menu com base no tamanho da tela
      const updateMenuButtonVisibility = () => {
        if (window.innerWidth < 768) {
          mobileMenuButton.style.display = "block";
        } else {
          mobileMenuButton.style.display = "none";
        }
      };
      
      // Verifica na carga inicial e redimensionamento
      updateMenuButtonVisibility();
      window.addEventListener("resize", updateMenuButtonVisibility);
    }
  }
  
  // ===== NAVEGAÇÃO SUAVE =====
  // Implementa rolagem suave para os links de navegação
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      e.preventDefault();
      
      const targetId = this.getAttribute('href');
      if (targetId === "#") return;
      
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        window.scrollTo({
          top: targetElement.offsetTop - 80, // Ajusta para o header fixo
          behavior: 'smooth'
        });
      }
    });
  });
  
  // ===== EFEITO PARALLAX PARA O SPLINE 3D =====
  const splineViewer = document.querySelector('spline-viewer');
  if (splineViewer) {
    window.addEventListener('scroll', () => {
      const scrollPosition = window.scrollY;
      const translateY = scrollPosition * 0.05; // Ajuste a velocidade do efeito
      splineViewer.style.transform = `translateY(${translateY}px)`;
    });
  }
});